package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        CartEntity::class,
        OrderEntity::class,
        FavoriteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao
    abstract fun favoriteDao(): FavoriteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gkart_ecommerce_database"
                )
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class AppDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.productDao())
                    }
                }
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                // Also ensure if table is empty, seed it
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        if (database.productDao().getCount() == 0) {
                            populateInitialData(database.productDao())
                        }
                    }
                }
            }
        }

        suspend fun populateInitialData(productDao: ProductDao) {
            val initialProducts = listOf(
                ProductEntity(
                    id = 1,
                    name = "Ultra Pro Wireless Earbuds ANC",
                    banglaName = "আল্ট্রা প্রো ওয়্যারলেস এয়ারবাডস",
                    category = "gadgets",
                    price = 1850.0,
                    originalPrice = 2500.0,
                    rating = 4.9f,
                    reviewCount = 340,
                    imageUrl = "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&auto=format&fit=crop&q=80",
                    sellerId = 1,
                    sellerName = "TechZone BD",
                    description = "Active Noise Cancellation (ANC), 36 hours total battery life, deep bass, IPX5 water resistance.",
                    banglaDescription = "অ্যাক্টিভ নয়েজ ক্যান্সেলেশন (ANC), ৩৬ ঘণ্টা ব্যাটারি ব্যাকআপ, হাই কোয়ালিটি ডিপ ব্যাস ও ওয়াটার রেসিস্ট্যান্ট।",
                    stock = 45,
                    isFeatured = true
                ),
                ProductEntity(
                    id = 2,
                    name = "Smart AMOLED Fitness Watch",
                    banglaName = "স্মার্ট অ্যামোলেড ফিটনেস ওয়াচ",
                    category = "gadgets",
                    price = 3200.0,
                    originalPrice = 4200.0,
                    rating = 4.8f,
                    reviewCount = 215,
                    imageUrl = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80",
                    sellerId = 1,
                    sellerName = "GKart Official",
                    description = "1.43-inch Always-on AMOLED display, Bluetooth calling, heart rate & SpO2 monitor, 100+ sports modes.",
                    banglaDescription = "১.৪৩ ইঞ্চি অ্যামোলেড ডিসপ্লে, ব্লুটুথ কলিং, হার্ট রেট ও ব্লাড অক্সিজেন ট্র্যাকিং সুবিধা।",
                    stock = 30,
                    isFeatured = true
                ),
                ProductEntity(
                    id = 3,
                    name = "Premium Cotton Embroidered Panjabi",
                    banglaName = "প্রিমিয়াম কটন এমব্রয়ডারি পাঞ্জাবি",
                    category = "fashion",
                    price = 2450.0,
                    originalPrice = 3200.0,
                    rating = 4.9f,
                    reviewCount = 180,
                    imageUrl = "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600&auto=format&fit=crop&q=80",
                    sellerId = 2,
                    sellerName = "Aarong Fashion Store",
                    description = "100% pure combed organic cotton with elegant collar thread embroidery. Comfortable for Eid and festivals.",
                    banglaDescription = "১০০% খাঁটি সুতি ফেব্রিক, রুচিশীল কলার এমব্রয়ডারি ও উৎসবের জন্য পারফেক্ট ক্যাজুয়াল ফিট।",
                    stock = 60,
                    isFeatured = true
                ),
                ProductEntity(
                    id = 4,
                    name = "Retro Leather Travel Backpack",
                    banglaName = "রেট্রো জেনুইন লেদার ব্যাকপ্যাক",
                    category = "fashion",
                    price = 3800.0,
                    originalPrice = 4900.0,
                    rating = 4.7f,
                    reviewCount = 95,
                    imageUrl = "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=80",
                    sellerId = 2,
                    sellerName = "Aarong Fashion Store",
                    description = "Handcrafted genuine leather backpack with 15.6-inch laptop compartment and anti-theft zipper.",
                    banglaDescription = "হাতে তৈরি জেনুইন লেদার ব্যাকপ্যাক, ল্যাপটপ চেম্বার এবং ওয়াটারপ্রুফ টেকসই ডিজাইন।",
                    stock = 25,
                    isFeatured = false
                ),
                ProductEntity(
                    id = 5,
                    name = "RGB Mechanical Gaming Keyboard",
                    banglaName = "মেকানিক্যাল গেমিং কীবোর্ড আরজিবি",
                    category = "electronics",
                    price = 2850.0,
                    originalPrice = 3500.0,
                    rating = 4.8f,
                    reviewCount = 152,
                    imageUrl = "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600&auto=format&fit=crop&q=80",
                    sellerId = 1,
                    sellerName = "TechZone BD",
                    description = "Blue tactile mechanical switches, customizable RGB backlighting, braided cable, full anti-ghosting keys.",
                    banglaDescription = "ব্লু ট্যাকটাইল মেকানিক্যাল সুইচ, আকর্ষণীয় আরজিবি লাইটিং ও টাইপিংয়ের অসাধারণ অভিজ্ঞতা।",
                    stock = 40,
                    isFeatured = true
                ),
                ProductEntity(
                    id = 6,
                    name = "Pure Organic Sunderbans Honey (500g)",
                    banglaName = "সুন্দরবনের খাঁটি প্রাকৃতিক মধু (৫০০ গ্রাম)",
                    category = "grocery",
                    price = 750.0,
                    originalPrice = 900.0,
                    rating = 5.0f,
                    reviewCount = 410,
                    imageUrl = "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=600&auto=format&fit=crop&q=80",
                    sellerId = 3,
                    sellerName = "Organic Bangla",
                    description = "100% raw wild honeycomb extract directly from Sundarbans mangrove forest. Natural immunity booster.",
                    banglaDescription = "সুন্দরবনের গভীর জঙ্গল থেকে সংগৃহীত ১০০% বিশুদ্ধ ও প্রাকৃতিক কাঁচা মধু। রোগ প্রতিরোধে অনন্য।",
                    stock = 85,
                    isFeatured = true
                ),
                ProductEntity(
                    id = 7,
                    name = "Ergonomic Office Desk Chair",
                    banglaName = "অর্গোনমিক অফিস ডেস্ক চেয়ার",
                    category = "lifestyle",
                    price = 8500.0,
                    originalPrice = 11000.0,
                    rating = 4.6f,
                    reviewCount = 78,
                    imageUrl = "https://images.unsplash.com/photo-1580481077195-c266858e5792?w=600&auto=format&fit=crop&q=80",
                    sellerId = 1,
                    sellerName = "GKart Official",
                    description = "Breathable mesh back, lumbar support, 3D adjustable armrests, heavy-duty tilt lock mechanism.",
                    banglaDescription = "দীর্ঘক্ষণ আরামদায়ক কাজের জন্য লাম্বার সাপোর্ট ও অ্যাডজাস্টেবল ব্যাকরেস্ট যুক্ত চেয়ার।",
                    stock = 15,
                    isFeatured = false
                ),
                ProductEntity(
                    id = 8,
                    name = "Portable Hi-Fi Bluetooth Speaker",
                    banglaName = "পোর্টেবল হাই-ফাই ব্লুটুথ স্পিকার",
                    category = "electronics",
                    price = 1600.0,
                    originalPrice = 2200.0,
                    rating = 4.8f,
                    reviewCount = 290,
                    imageUrl = "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600&auto=format&fit=crop&q=80",
                    sellerId = 1,
                    sellerName = "TechZone BD",
                    description = "360-degree surround sound, RGB beat lighting, 12-hour continuous playtime, TWS pairing.",
                    banglaDescription = "৩৬০ ডিগ্রি ক্রিস্টাল ক্লিয়ার সাউন্ড, আরজিবি বিট লাইট ও ১২ ঘণ্টা ব্যাকআপ।",
                    stock = 50,
                    isFeatured = true
                )
            )
            productDao.insertProducts(initialProducts)
        }
    }
}
