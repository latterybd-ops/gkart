package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppLanguage
import com.example.data.model.CartItem
import com.example.data.model.Category
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import com.example.data.remote.ApiException
import com.example.data.remote.SellerSession
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ShopTab {
    HOME,
    CART,
    ORDERS,
    FAVORITES,
    SELLER
}

class ShopViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ShopRepository
    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = ShopRepository(db)
    }

    val categories = listOf(
        Category("all", "All", "সব", "grid_view"),
        Category("gadgets", "Gadgets", "গ্যাজেট", "devices"),
        Category("fashion", "Fashion", "ফ্যাশন", "checkroom"),
        Category("electronics", "Electronics", "ইলেকট্রনিক্স", "bolt"),
        Category("grocery", "Grocery", "গ্রোসারি", "shopping_basket"),
        Category("lifestyle", "Lifestyle", "লাইফস্টাইল", "chair")
    )

    private val _currentLanguage = MutableStateFlow(AppLanguage.BANGLA)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _activeTab = MutableStateFlow(ShopTab.HOME)
    val activeTab: StateFlow<ShopTab> = _activeTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("all")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    private val _snackbarEvent = MutableSharedFlow<String>()
    val snackbarEvent: SharedFlow<String> = _snackbarEvent.asSharedFlow()

    // Promo Code state
    private val _appliedPromoCode = MutableStateFlow("")
    val appliedPromoCode: StateFlow<String> = _appliedPromoCode.asStateFlow()

    private val _promoDiscount = MutableStateFlow(0.0)
    val promoDiscount: StateFlow<Double> = _promoDiscount.asStateFlow()

    private val _orderSuccess = MutableStateFlow<Order?>(null)
    val orderSuccess: StateFlow<Order?> = _orderSuccess.asStateFlow()

    val rawProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredProducts: StateFlow<List<Product>> = combine(
        rawProducts,
        _searchQuery,
        _selectedCategory
    ) { products, query, cat ->
        products.filter { product ->
            val matchesCategory = cat == "all" || product.category.equals(cat, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                    product.name.contains(query, ignoreCase = true) ||
                    product.banglaName.contains(query, ignoreCase = true) ||
                    product.category.contains(query, ignoreCase = true) ||
                    product.sellerName.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartCount: StateFlow<Int> = cartItems.map { list ->
        list.sumOf { it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val cartSubtotal: StateFlow<Double> = cartItems.map { list ->
        list.sumOf { it.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val deliveryFee: StateFlow<Double> = cartSubtotal.map { subtotal ->
        if (subtotal > 0) 60.0 else 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val grandTotal: StateFlow<Double> = combine(cartSubtotal, deliveryFee, _promoDiscount) { sub, fee, disc ->
        maxOf(0.0, sub + fee - disc)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val favoriteIds: StateFlow<Set<Long>> = repository.favoriteIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val favoriteProducts: StateFlow<List<Product>> = combine(rawProducts, favoriteIds) { products, favIds ->
        products.filter { it.id in favIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---------------- সার্ভার সংযোগ ও সেলার সেশন ----------------
    private val prefs = application.getSharedPreferences("gkart_prefs", Context.MODE_PRIVATE)
    private var catalogSynced = prefs.getBoolean("catalog_synced", false)
    private var lastRefresh = 0L

    private val _sellerSession = MutableStateFlow<SellerSession?>(loadSession())
    val sellerSession: StateFlow<SellerSession?> = _sellerSession.asStateFlow()

    private val _sellerOrders = MutableStateFlow<List<Order>>(emptyList())
    val sellerOrders: StateFlow<List<Order>> = _sellerOrders.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _syncError = MutableStateFlow<String?>(null)
    val syncError: StateFlow<String?> = _syncError.asStateFlow()

    val sellerProducts: StateFlow<List<Product>> = combine(rawProducts, _sellerSession) { list, session ->
        if (session == null) emptyList() else list.filter { it.sellerId == session.userId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.BANGLA) {
            AppLanguage.ENGLISH
        } else {
            AppLanguage.BANGLA
        }
    }

    fun setActiveTab(tab: ShopTab) {
        _activeTab.value = tab
        if (tab == ShopTab.HOME || tab == ShopTab.ORDERS || tab == ShopTab.SELLER) {
            refreshAll()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(catId: String) {
        _selectedCategory.value = catId
    }

    fun openProductDetail(product: Product) {
        _selectedProduct.value = product
    }

    fun closeProductDetail() {
        _selectedProduct.value = null
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToCart(product, quantity)
            val msg = if (_currentLanguage.value == AppLanguage.BANGLA) {
                "কার্টে যোগ করা হয়েছে: ${product.banglaName}"
            } else {
                "Added to Cart: ${product.name}"
            }
            _snackbarEvent.emit(msg)
        }
    }

    fun updateCartQuantity(cartId: Long, newQuantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(cartId, newQuantity)
        }
    }

    fun removeFromCart(cartId: Long) {
        viewModelScope.launch {
            repository.removeFromCart(cartId)
            val msg = if (_currentLanguage.value == AppLanguage.BANGLA) {
                "পণ্যটি কার্ট থেকে সরানো হয়েছে"
            } else {
                "Item removed from cart"
            }
            _snackbarEvent.emit(msg)
        }
    }

    fun toggleFavorite(productId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(productId)
        }
    }

    fun applyPromoCode(code: String) {
        val trimmed = code.trim().uppercase()
        val sub = cartSubtotal.value
        when (trimmed) {
            "GKART50" -> {
                if (sub >= 1000) {
                    _appliedPromoCode.value = trimmed
                    _promoDiscount.value = 250.0
                    viewModelScope.launch {
                        _snackbarEvent.emit(
                            if (_currentLanguage.value == AppLanguage.BANGLA) "২৫০ টাকা ডিসকাউন্ট কুপন যুক্ত হয়েছে!"
                            else "৳250 discount applied!"
                        )
                    }
                } else {
                    viewModelScope.launch {
                        _snackbarEvent.emit(
                            if (_currentLanguage.value == AppLanguage.BANGLA) "এই কুপনটির জন্য কমপক্ষে ১০০০ টাকার অর্ডার লাগবে"
                            else "Minimum ৳1,000 order required for this coupon"
                        )
                    }
                }
            }
            "EID2026", "SPECIAL10" -> {
                val discount = (sub * 0.15).coerceAtMost(500.0)
                _appliedPromoCode.value = trimmed
                _promoDiscount.value = discount
                viewModelScope.launch {
                    _snackbarEvent.emit(
                        if (_currentLanguage.value == AppLanguage.BANGLA) "১৫% বিশেষ ঈদ ছাড় যুক্ত হয়েছে!"
                        else "15% Eid special discount applied!"
                    )
                }
            }
            else -> {
                viewModelScope.launch {
                    _snackbarEvent.emit(
                        if (_currentLanguage.value == AppLanguage.BANGLA) "অবৈধ প্রোমোকোড! চেষ্টা করুন: EID2026 অথবা GKART50"
                        else "Invalid promo code! Try: EID2026 or GKART50"
                    )
                }
            }
        }
    }

    fun checkout(customerName: String, phone: String, address: String, paymentMethod: String) {
        viewModelScope.launch {
            val items = cartItems.value
            if (items.isEmpty()) return@launch

            if (!catalogSynced) {
                say(
                    "প্রোডাক্ট তালিকা এখনো সার্ভার থেকে আসেনি। ইন্টারনেট চেক করে আবার চেষ্টা করুন।",
                    "Product list is not synced with the server yet. Check your connection and retry."
                )
                refreshAll(force = true)
                return@launch
            }

            _isBusy.value = true
            try {
                val order = repository.placeOrderRemote(
                    customerName = customerName,
                    phone = phone,
                    address = address,
                    paymentMethod = paymentMethod,
                    promoCode = _appliedPromoCode.value,
                    items = items
                )
                _orderSuccess.value = order
                _appliedPromoCode.value = ""
                _promoDiscount.value = 0.0
                say(
                    "অভিনন্দন! আপনার অর্ডার সফলভাবে গ্রহণ করা হয়েছে।",
                    "Congratulations! Your order has been placed successfully."
                )
                refreshAll(force = true)
            } catch (e: ApiException) {
                say(e.message ?: "অর্ডার করা যায়নি", e.message ?: "Could not place the order")
            } catch (e: Exception) {
                say("অর্ডার করা যায়নি। আবার চেষ্টা করুন।", "Could not place the order. Please try again.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun dismissOrderSuccess() {
        _orderSuccess.value = null
        _activeTab.value = ShopTab.ORDERS
    }

    // ------------------------------------------------------------------
    // সেলার: সার্ভারে লগইন করে প্রোডাক্ট যোগ/মোছা (ওয়েবসাইটের seller.php এর মতোই)
    // ------------------------------------------------------------------
    fun sellerLogin(email: String, password: String) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val session = repository.sellerLogin(email.trim(), password)
                saveSession(session)
                _sellerSession.value = session
                refreshAll(force = true)
                say("লগইন সফল! স্বাগতম, ${session.name}", "Logged in! Welcome, ${session.name}")
            } catch (e: ApiException) {
                say(e.message ?: "লগইন করা যায়নি", e.message ?: "Login failed")
            } catch (e: Exception) {
                say("লগইন করা যায়নি। আবার চেষ্টা করুন।", "Login failed. Please try again.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun sellerLogout() {
        prefs.edit().remove("seller_token").remove("seller_id").remove("seller_name").remove("seller_role").apply()
        _sellerSession.value = null
        _sellerOrders.value = emptyList()
    }

    fun addSellerProduct(
        name: String,
        banglaName: String,
        category: String,
        price: Double,
        originalPrice: Double,
        imageUrl: String,
        description: String,
        stock: Int
    ) {
        val session = _sellerSession.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                repository.sellerAddProduct(
                    token = session.token,
                    name = name,
                    banglaName = banglaName,
                    category = category,
                    price = price,
                    originalPrice = originalPrice,
                    imageUrl = imageUrl,
                    description = description,
                    stock = stock
                )
                repository.syncProducts()
                say("প্রোডাক্ট সফলভাবে আপলোড হয়েছে!", "Product added successfully!")
            } catch (e: ApiException) {
                if (e.unauthorized) sellerLogout()
                say(e.message ?: "আপলোড করা যায়নি", e.message ?: "Upload failed")
            } catch (e: Exception) {
                say("আপলোড করা যায়নি। আবার চেষ্টা করুন।", "Upload failed. Please try again.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun deleteProduct(productId: Long) {
        val session = _sellerSession.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                repository.sellerDeleteProduct(session.token, productId)
                repository.syncProducts()
                say("প্রোডাক্ট মুছে ফেলা হয়েছে", "Product deleted")
            } catch (e: ApiException) {
                if (e.unauthorized) sellerLogout()
                say(e.message ?: "মোছা যায়নি", e.message ?: "Could not delete")
            } catch (e: Exception) {
                say("মোছা যায়নি। আবার চেষ্টা করুন।", "Could not delete. Please try again.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    // ------------------------------------------------------------------
    // সার্ভারের সাথে সিঙ্ক (প্রোডাক্ট, অর্ডারের স্ট্যাটাস, সেলারের অর্ডার)
    // ------------------------------------------------------------------
    fun refreshAll(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastRefresh < 20_000) return
        lastRefresh = now
        viewModelScope.launch {
            try {
                repository.syncProducts()
                catalogSynced = true
                prefs.edit().putBoolean("catalog_synced", true).apply()
                _syncError.value = null
            } catch (e: ApiException) {
                _syncError.value = e.message
            } catch (e: Exception) {
                _syncError.value = "সার্ভারের সাথে সংযোগ হয়নি"
            }

            try {
                repository.refreshOrderStatuses()
            } catch (_: Exception) {
            }

            val session = _sellerSession.value
            if (session != null) {
                try {
                    _sellerOrders.value = repository.sellerOrders(session.token)
                } catch (e: ApiException) {
                    if (e.unauthorized) sellerLogout()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun saveSession(session: SellerSession) {
        prefs.edit()
            .putString("seller_token", session.token)
            .putLong("seller_id", session.userId)
            .putString("seller_name", session.name)
            .putString("seller_role", session.role)
            .apply()
    }

    private fun loadSession(): SellerSession? {
        val token = prefs.getString("seller_token", null) ?: return null
        return SellerSession(
            token = token,
            userId = prefs.getLong("seller_id", 0),
            name = prefs.getString("seller_name", "") ?: "",
            role = prefs.getString("seller_role", "seller") ?: "seller"
        )
    }

    private suspend fun say(bangla: String, english: String) {
        _snackbarEvent.emit(if (_currentLanguage.value == AppLanguage.BANGLA) bangla else english)
    }

    init {
        // সব property তৈরি হওয়ার পরে অ্যাপ খুলতেই সার্ভার থেকে তথ্য আনা
        refreshAll(force = true)
    }
}
