package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.screens.SellerLoginScreen
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.ui.components.ShopBottomNav
import com.example.ui.components.ShopTopBar
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CheckoutDialog
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OrderSuccessDialog
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProductDetailSheet
import com.example.ui.screens.SellerScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ShopTab
import com.example.ui.viewmodel.ShopViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: ShopViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                GKartApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun GKartApp(viewModel: ShopViewModel) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val rawProducts by viewModel.rawProducts.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartCount by viewModel.cartCount.collectAsStateWithLifecycle()
    val cartSubtotal by viewModel.cartSubtotal.collectAsStateWithLifecycle()
    val deliveryFee by viewModel.deliveryFee.collectAsStateWithLifecycle()
    val promoDiscount by viewModel.promoDiscount.collectAsStateWithLifecycle()
    val grandTotal by viewModel.grandTotal.collectAsStateWithLifecycle()
    val appliedPromoCode by viewModel.appliedPromoCode.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val favoriteProducts by viewModel.favoriteProducts.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val orderSuccess by viewModel.orderSuccess.collectAsStateWithLifecycle()
    val sellerSession by viewModel.sellerSession.collectAsStateWithLifecycle()
    val sellerProducts by viewModel.sellerProducts.collectAsStateWithLifecycle()
    val sellerOrders by viewModel.sellerOrders.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val syncError by viewModel.syncError.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showCheckoutDialog by remember { mutableStateOf(false) }

    // Handle back button: return to Home tab if on another tab
    BackHandler(enabled = activeTab != ShopTab.HOME) {
        viewModel.setActiveTab(ShopTab.HOME)
    }

    // Collect snackbar events
    LaunchedEffect(Unit) {
        viewModel.snackbarEvent.collectLatest { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        topBar = {
            ShopTopBar(
                currentLanguage = currentLanguage,
                activeTab = activeTab,
                favoriteCount = favoriteIds.size,
                onLanguageToggle = { viewModel.toggleLanguage() },
                onTabSelected = { viewModel.setActiveTab(it) }
            )
        },
        bottomBar = {
            ShopBottomNav(
                activeTab = activeTab,
                cartCount = cartCount,
                orderCount = orders.size,
                currentLanguage = currentLanguage,
                onTabSelected = { viewModel.setActiveTab(it) }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    ShopTab.HOME -> {
                        HomeScreen(
                            products = products,
                            categories = viewModel.categories,
                            selectedCategory = selectedCategory,
                            searchQuery = searchQuery,
                            favoriteIds = favoriteIds,
                            currentLanguage = currentLanguage,
                            onCategorySelect = { viewModel.selectCategory(it) },
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onProductClick = { viewModel.openProductDetail(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onApplyCoupon = { code ->
                                viewModel.applyPromoCode(code)
                                viewModel.setActiveTab(ShopTab.CART)
                            }
                        )
                    }

                    ShopTab.CART -> {
                        CartScreen(
                            cartItems = cartItems,
                            subtotal = cartSubtotal,
                            deliveryFee = deliveryFee,
                            discount = promoDiscount,
                            grandTotal = grandTotal,
                            appliedCoupon = appliedPromoCode,
                            currentLanguage = currentLanguage,
                            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
                            onRemoveItem = { id -> viewModel.removeFromCart(id) },
                            onApplyCoupon = { code -> viewModel.applyPromoCode(code) },
                            onStartShopping = { viewModel.setActiveTab(ShopTab.HOME) },
                            onProceedToCheckout = { showCheckoutDialog = true }
                        )
                    }

                    ShopTab.ORDERS -> {
                        OrdersScreen(
                            orders = orders,
                            currentLanguage = currentLanguage,
                            onStartShopping = { viewModel.setActiveTab(ShopTab.HOME) }
                        )
                    }

                    ShopTab.FAVORITES -> {
                        FavoritesScreen(
                            favoriteProducts = favoriteProducts,
                            currentLanguage = currentLanguage,
                            onProductClick = { viewModel.openProductDetail(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onStartShopping = { viewModel.setActiveTab(ShopTab.HOME) }
                        )
                    }

                    ShopTab.SELLER -> {
                        val session = sellerSession
                        if (session == null) {
                            SellerLoginScreen(
                                currentLanguage = currentLanguage,
                                isBusy = isBusy,
                                onLogin = { email, password -> viewModel.sellerLogin(email, password) }
                            )
                        } else {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (currentLanguage == AppLanguage.BANGLA) {
                                            "লগইন: ${session.name}"
                                        } else {
                                            "Signed in: ${session.name}"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = { viewModel.sellerLogout() }) {
                                        Text(if (currentLanguage == AppLanguage.BANGLA) "লগআউট" else "Log out")
                                    }
                                }
                                Box(modifier = Modifier.weight(1f)) {
                                    SellerScreen(
                                        products = sellerProducts,
                                        orders = sellerOrders,
                                        categories = viewModel.categories,
                                        currentLanguage = currentLanguage,
                                        onAddProduct = { name, bName, cat, price, origPrice, img, desc, stock ->
                                            viewModel.addSellerProduct(name, bName, cat, price, origPrice, img, desc, stock)
                                        },
                                        onDeleteProduct = { viewModel.deleteProduct(it) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // চলমান কাজের লোডিং বার
            if (isBusy) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .align(Alignment.TopCenter)
                )
            }

            // সার্ভারের সাথে সংযোগ না হলে ব্যানার (ট্যাপ করলে আবার চেষ্টা)
            syncError?.let { message ->
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.refreshAll(force = true) }) {
                            Text(if (currentLanguage == AppLanguage.BANGLA) "আবার চেষ্টা" else "Retry")
                        }
                    }
                }
            }
        }
    }

    // Product Detail Bottom Sheet
    selectedProduct?.let { product ->
        ProductDetailSheet(
            product = product,
            currentLanguage = currentLanguage,
            onDismiss = { viewModel.closeProductDetail() },
            onAddToCart = { prod, qty -> viewModel.addToCart(prod, qty) },
            onBuyNow = { prod, qty ->
                viewModel.addToCart(prod, qty)
                showCheckoutDialog = true
            }
        )
    }

    // Checkout Dialog
    if (showCheckoutDialog) {
        CheckoutDialog(
            totalAmount = grandTotal,
            currentLanguage = currentLanguage,
            onDismiss = { showCheckoutDialog = false },
            onConfirmOrder = { name, phone, address, payment ->
                viewModel.checkout(name, phone, address, payment)
            }
        )
    }

    // Order Success Celebration Modal
    orderSuccess?.let { order ->
        OrderSuccessDialog(
            order = order,
            currentLanguage = currentLanguage,
            onDismiss = { viewModel.dismissOrderSuccess() }
        )
    }
}
