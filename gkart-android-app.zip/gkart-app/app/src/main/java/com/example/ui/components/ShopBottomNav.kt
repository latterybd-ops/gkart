package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ListAlt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.ui.theme.BrandAmber
import com.example.ui.viewmodel.ShopTab

@Composable
fun ShopBottomNav(
    activeTab: ShopTab,
    cartCount: Int,
    orderCount: Int,
    currentLanguage: AppLanguage,
    onTabSelected: (ShopTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        // Home Tab
        NavigationBarItem(
            selected = activeTab == ShopTab.HOME,
            onClick = { onTabSelected(ShopTab.HOME) },
            icon = {
                Icon(
                    imageVector = if (activeTab == ShopTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = {
                Text(
                    text = if (currentLanguage == AppLanguage.BANGLA) "হোম" else "Home",
                    fontWeight = if (activeTab == ShopTab.HOME) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_home_tab")
        )

        // Cart Tab
        NavigationBarItem(
            selected = activeTab == ShopTab.CART,
            onClick = { onTabSelected(ShopTab.CART) },
            icon = {
                BadgedBox(
                    badge = {
                        if (cartCount > 0) {
                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text("$cartCount", color = Color.White)
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (activeTab == ShopTab.CART) Icons.Filled.ShoppingCart else Icons.Outlined.ShoppingCart,
                        contentDescription = "Cart"
                    )
                }
            },
            label = {
                Text(
                    text = if (currentLanguage == AppLanguage.BANGLA) "কার্ট" else "Cart",
                    fontWeight = if (activeTab == ShopTab.CART) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_cart_tab")
        )

        // Orders Tab
        NavigationBarItem(
            selected = activeTab == ShopTab.ORDERS,
            onClick = { onTabSelected(ShopTab.ORDERS) },
            icon = {
                BadgedBox(
                    badge = {
                        if (orderCount > 0) {
                            Badge(containerColor = BrandAmber) {
                                Text("$orderCount", color = Color.White)
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ListAlt,
                        contentDescription = "Orders"
                    )
                }
            },
            label = {
                Text(
                    text = if (currentLanguage == AppLanguage.BANGLA) "অর্ডার" else "Orders",
                    fontWeight = if (activeTab == ShopTab.ORDERS) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_orders_tab")
        )

        // Seller Hub Tab
        NavigationBarItem(
            selected = activeTab == ShopTab.SELLER,
            onClick = { onTabSelected(ShopTab.SELLER) },
            icon = {
                Icon(
                    imageVector = if (activeTab == ShopTab.SELLER) Icons.Filled.Storefront else Icons.Outlined.Storefront,
                    contentDescription = "Seller"
                )
            },
            label = {
                Text(
                    text = if (currentLanguage == AppLanguage.BANGLA) "সেলার" else "Seller",
                    fontWeight = if (activeTab == ShopTab.SELLER) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_seller_tab")
        )
    }
}
