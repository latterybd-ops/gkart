package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.CartItem
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val banglaName: String,
    val category: String,
    val price: Double,
    val originalPrice: Double,
    val rating: Float,
    val reviewCount: Int,
    val imageUrl: String,
    val sellerId: Long,
    val sellerName: String,
    val description: String,
    val banglaDescription: String,
    val stock: Int,
    val isFeatured: Boolean
) {
    fun toDomain(): Product = Product(
        id = id,
        name = name,
        banglaName = banglaName,
        category = category,
        price = price,
        originalPrice = originalPrice,
        rating = rating,
        reviewCount = reviewCount,
        imageUrl = imageUrl,
        sellerId = sellerId,
        sellerName = sellerName,
        description = description,
        banglaDescription = banglaDescription,
        stock = stock,
        isFeatured = isFeatured
    )

    companion object {
        fun fromDomain(product: Product): ProductEntity = ProductEntity(
            id = product.id,
            name = product.name,
            banglaName = product.banglaName,
            category = product.category,
            price = product.price,
            originalPrice = product.originalPrice,
            rating = product.rating,
            reviewCount = product.reviewCount,
            imageUrl = product.imageUrl,
            sellerId = product.sellerId,
            sellerName = product.sellerName,
            description = product.description,
            banglaDescription = product.banglaDescription,
            stock = product.stock,
            isFeatured = product.isFeatured
        )
    }
}

@Entity(tableName = "cart_items")
data class CartEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val banglaName: String,
    val price: Double,
    val imageUrl: String,
    val quantity: Int,
    val sellerName: String
) {
    fun toDomain(): CartItem = CartItem(
        id = id,
        productId = productId,
        productName = productName,
        banglaName = banglaName,
        price = price,
        imageUrl = imageUrl,
        quantity = quantity,
        sellerName = sellerName
    )

    companion object {
        fun fromDomain(item: CartItem): CartEntity = CartEntity(
            id = item.id,
            productId = item.productId,
            productName = item.productName,
            banglaName = item.banglaName,
            price = item.price,
            imageUrl = item.imageUrl,
            quantity = item.quantity,
            sellerName = item.sellerName
        )
    }
}

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderNumber: String,
    val date: String,
    val totalAmount: Double,
    val status: String,
    val customerName: String,
    val phone: String,
    val address: String,
    val paymentMethod: String,
    val itemsSummary: String,
    val totalQuantity: Int
) {
    fun toDomain(): Order = Order(
        id = id,
        orderNumber = orderNumber,
        date = date,
        totalAmount = totalAmount,
        status = try {
            OrderStatus.valueOf(status)
        } catch (_: Exception) {
            OrderStatus.PENDING
        },
        customerName = customerName,
        phone = phone,
        address = address,
        paymentMethod = paymentMethod,
        itemsSummary = itemsSummary,
        totalQuantity = totalQuantity
    )

    companion object {
        fun fromDomain(order: Order): OrderEntity = OrderEntity(
            id = order.id,
            orderNumber = order.orderNumber,
            date = order.date,
            totalAmount = order.totalAmount,
            status = order.status.name,
            customerName = order.customerName,
            phone = order.phone,
            address = order.address,
            paymentMethod = order.paymentMethod,
            itemsSummary = order.itemsSummary,
            totalQuantity = order.totalQuantity
        )
    }
}

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val productId: Long,
    val addedAt: Long = System.currentTimeMillis()
)
