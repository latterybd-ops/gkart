package com.example.data.model

data class Product(
    val id: Long = 0,
    val name: String,
    val banglaName: String,
    val category: String,
    val price: Double,
    val originalPrice: Double,
    val rating: Float = 4.8f,
    val reviewCount: Int = 120,
    val imageUrl: String,
    val sellerId: Long = 1,
    val sellerName: String = "GKart Official",
    val description: String,
    val banglaDescription: String,
    val stock: Int = 50,
    val isFeatured: Boolean = false
)

data class CartItem(
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val banglaName: String,
    val price: Double,
    val imageUrl: String,
    val quantity: Int = 1,
    val sellerName: String = "GKart Official"
)

data class Order(
    val id: Long = 0,
    val orderNumber: String,
    val date: String,
    val totalAmount: Double,
    val status: OrderStatus = OrderStatus.PENDING,
    val customerName: String,
    val phone: String,
    val address: String,
    val paymentMethod: String,
    val itemsSummary: String,
    val totalQuantity: Int
)

enum class OrderStatus(val labelEn: String, val labelBn: String) {
    PENDING("Processing", "প্রক্রিয়াধীন"),
    CONFIRMED("Confirmed", "নিশ্চিত হয়েছে"),
    SHIPPED("Shipped", "পাঠানো হয়েছে"),
    OUT_FOR_DELIVERY("Out for Delivery", "ডেলিভারির পথে"),
    DELIVERED("Delivered", "ডেলিভারি সম্পন্ন"),
    CANCELLED("Cancelled", "বাতিল")
}

data class Category(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val iconKey: String
)

enum class AppLanguage {
    BANGLA, ENGLISH
}
