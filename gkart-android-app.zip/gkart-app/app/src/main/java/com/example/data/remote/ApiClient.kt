package com.example.data.remote

import com.example.data.model.CartItem
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * ⚠️ আপনার ওয়েবসাইটের api.php এর ঠিকানা এখানে বসান।
 * api.php যদি কোনো ফোল্ডারে রাখেন (যেমন /gkart/), তাহলে এভাবে লিখুন:
 * "https://jamjam.xo.je/gkart/api.php"
 */
object ApiConfig {
    const val BASE_URL = "https://jamjam.xo.je/api.php"
}

class ApiException(message: String, val unauthorized: Boolean = false) : Exception(message)

data class SellerSession(val token: String, val userId: Long, val name: String, val role: String)

data class RemoteOrder(
    val id: Long,
    val orderNumber: String,
    val status: String,
    val subtotal: Double,
    val deliveryFee: Double,
    val discount: Double,
    val total: Double
)

object ApiClient {

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 13; GKart) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // InfinityFree-র "ব্রাউজার চেক" পার করার কুকি (মেমরিতে রাখা হয়)
    @Volatile
    private var testCookie: String? = null

    /* -------------------------------------------------------------
     * নিচের অংশটা InfinityFree ফ্রি হোস্টিং-এর অ্যান্টি-বট সিস্টেমের জন্য।
     * অ্যাপের মতো non-browser ক্লায়েন্টকে ওরা জাভাস্ক্রিপ্ট চ্যালেঞ্জের HTML পাঠায়।
     * চ্যালেঞ্জটা (AES) আমরা নিজেরাই সমাধান করে কুকি সহ আবার রিকোয়েস্ট পাঠাই।
     * ------------------------------------------------------------- */
    private fun hexToBytes(hex: String): ByteArray {
        val out = ByteArray(hex.length / 2)
        for (i in out.indices) {
            out[i] = hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
        return out
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    private fun solveChallenge(html: String): String? {
        if (!html.contains("slowAES") && !html.contains("toNumbers")) return null
        val values = Regex("toNumbers\\(\"([0-9a-fA-F]+)\"\\)").findAll(html).map { it.groupValues[1] }.toList()
        if (values.size < 3) return null
        return try {
            val key = hexToBytes(values[0])
            val iv = hexToBytes(values[1])
            val data = hexToBytes(values[2])
            val cipher = Cipher.getInstance("AES/CBC/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
            bytesToHex(cipher.doFinal(data))
        } catch (_: Exception) {
            null
        }
    }

    private fun execute(makeRequest: (cookie: String?) -> Request): String {
        var cookie = testCookie
        repeat(3) {
            val response = try {
                client.newCall(makeRequest(cookie)).execute()
            } catch (e: IOException) {
                throw ApiException("ইন্টারনেট সংযোগ বা সার্ভারে সমস্যা। পরে আবার চেষ্টা করুন।")
            }
            val body = try {
                response.body?.string().orEmpty()
            } finally {
                response.close()
            }
            val solved = solveChallenge(body) ?: return body
            cookie = solved
            testCookie = solved
        }
        throw ApiException("সার্ভার অ্যাপের রিকোয়েস্ট আটকে দিচ্ছে (হোস্টিং-এর বট প্রোটেকশন)।")
    }

    private fun buildUrl(action: String, query: Map<String, String>, cookie: String?): String {
        val builder = ApiConfig.BASE_URL.toHttpUrl().newBuilder().addQueryParameter("action", action)
        for ((k, v) in query) builder.addQueryParameter(k, v)
        if (cookie != null) builder.addQueryParameter("i", "1")
        return builder.build().toString()
    }

    private fun parse(body: String): JSONObject {
        val json = try {
            JSONObject(body.trim())
        } catch (_: Exception) {
            throw ApiException("সার্ভার থেকে সঠিক উত্তর আসেনি। api.php আপলোড ও ঠিকানা (BASE_URL) চেক করুন।")
        }
        if (!json.optBoolean("ok", false)) {
            val code401 = json.optString("error").contains("লগইন")
            throw ApiException(json.optString("error", "অজানা সমস্যা"), unauthorized = code401)
        }
        return json
    }

    private fun get(action: String, query: Map<String, String> = emptyMap()): JSONObject {
        val body = execute { cookie ->
            val builder = Request.Builder()
                .url(buildUrl(action, query, cookie))
                .header("User-Agent", USER_AGENT)
                .get()
            if (cookie != null) builder.header("Cookie", "__test=$cookie")
            builder.build()
        }
        return parse(body)
    }

    private fun post(action: String, fields: Map<String, String>): JSONObject {
        val body = execute { cookie ->
            val form = FormBody.Builder()
            for ((k, v) in fields) form.add(k, v)
            val builder = Request.Builder()
                .url(buildUrl(action, emptyMap(), cookie))
                .header("User-Agent", USER_AGENT)
                .post(form.build())
            if (cookie != null) builder.header("Cookie", "__test=$cookie")
            builder.build()
        }
        return parse(body)
    }

    /* ---------------------------- প্রোডাক্ট ---------------------------- */

    private fun productFrom(o: JSONObject): Product = Product(
        id = o.getLong("id"),
        name = o.getString("name"),
        banglaName = o.optString("banglaName", o.getString("name")),
        category = o.optString("category", "gadgets"),
        price = o.getDouble("price"),
        originalPrice = o.optDouble("originalPrice", o.getDouble("price")),
        imageUrl = o.optString("imageUrl", ""),
        sellerId = o.optLong("sellerId", 0),
        sellerName = o.optString("sellerName", "GKart"),
        description = o.optString("description", ""),
        banglaDescription = o.optString("banglaDescription", o.optString("description", "")),
        stock = o.optInt("stock", 0),
        isFeatured = o.optBoolean("isFeatured", false)
    )

    private fun productsFrom(json: JSONObject): List<Product> {
        val arr: JSONArray = json.getJSONArray("products")
        return (0 until arr.length()).map { productFrom(arr.getJSONObject(it)) }
    }

    fun fetchProducts(): List<Product> = productsFrom(get("products"))

    /* ----------------------------- অর্ডার ----------------------------- */

    fun createOrder(
        name: String,
        phone: String,
        address: String,
        payment: String,
        promo: String,
        items: List<CartItem>
    ): RemoteOrder {
        val arr = JSONArray()
        for (item in items) {
            arr.put(JSONObject().put("id", item.productId).put("qty", item.quantity))
        }
        val json = post(
            "create_order",
            mapOf(
                "name" to name,
                "phone" to phone,
                "address" to address,
                "payment" to payment,
                "promo" to promo,
                "items" to arr.toString()
            )
        )
        val o = json.getJSONObject("order")
        return RemoteOrder(
            id = o.getLong("id"),
            orderNumber = o.getString("order_number"),
            status = o.getString("status"),
            subtotal = o.getDouble("subtotal"),
            deliveryFee = o.getDouble("delivery_fee"),
            discount = o.getDouble("discount"),
            total = o.getDouble("total")
        )
    }

    /** আগের অর্ডারগুলোর বর্তমান স্ট্যাটাস: অর্ডার নম্বর -> স্ট্যাটাস */
    fun trackOrders(orders: List<Pair<String, String>>): Map<String, String> {
        if (orders.isEmpty()) return emptyMap()
        val arr = JSONArray()
        for ((number, phone) in orders) arr.put(JSONObject().put("n", number).put("p", phone))
        val json = post("track_many", mapOf("orders" to arr.toString()))
        val st = json.getJSONObject("statuses")
        val out = mutableMapOf<String, String>()
        for (key in st.keys()) out[key] = st.getString(key)
        return out
    }

    /* ------------------------------ সেলার ------------------------------ */

    fun login(email: String, password: String): SellerSession {
        val json = post("login", mapOf("email" to email, "password" to password))
        val u = json.getJSONObject("user")
        return SellerSession(
            token = json.getString("token"),
            userId = u.getLong("id"),
            name = u.getString("name"),
            role = u.getString("role")
        )
    }

    fun sellerProducts(token: String): List<Product> =
        productsFrom(post("seller_products", mapOf("token" to token)))

    fun addProduct(
        token: String,
        name: String,
        banglaName: String,
        category: String,
        price: Double,
        originalPrice: Double,
        imageUrl: String,
        description: String,
        stock: Int
    ) {
        post(
            "add_product",
            mapOf(
                "token" to token,
                "name" to name,
                "name_bn" to banglaName,
                "category" to category,
                "price" to price.toString(),
                "original_price" to originalPrice.toString(),
                "image_url" to imageUrl,
                "description" to description,
                "stock" to stock.toString()
            )
        )
    }

    fun deleteProduct(token: String, productId: Long) {
        post("delete_product", mapOf("token" to token, "id" to productId.toString()))
    }

    fun sellerOrders(token: String): List<Order> {
        val json = post("seller_orders", mapOf("token" to token))
        val arr = json.getJSONArray("orders")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Order(
                id = o.getLong("id"),
                orderNumber = o.getString("orderNumber"),
                date = o.optString("date", ""),
                totalAmount = o.getDouble("totalAmount"),
                status = try {
                    OrderStatus.valueOf(o.getString("status"))
                } catch (_: Exception) {
                    OrderStatus.PENDING
                },
                customerName = o.optString("customerName", ""),
                phone = o.optString("phone", ""),
                address = o.optString("address", ""),
                paymentMethod = o.optString("paymentMethod", ""),
                itemsSummary = o.optString("itemsSummary", ""),
                totalQuantity = o.optInt("totalQuantity", 0)
            )
        }
    }
}
