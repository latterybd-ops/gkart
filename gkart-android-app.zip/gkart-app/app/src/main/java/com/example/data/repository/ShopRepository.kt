package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.CartEntity
import com.example.data.local.FavoriteEntity
import com.example.data.local.OrderEntity
import com.example.data.local.ProductEntity
import com.example.data.model.CartItem
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import com.example.data.remote.ApiClient
import com.example.data.remote.SellerSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ShopRepository(private val database: AppDatabase) {

    private val productDao = database.productDao()
    private val cartDao = database.cartDao()
    private val orderDao = database.orderDao()
    private val favoriteDao = database.favoriteDao()

    val allProducts: Flow<List<Product>> = productDao.getAllProducts().map { entities ->
        entities.map { it.toDomain() }
    }

    val cartItems: Flow<List<CartItem>> = cartDao.getCartItems().map { entities ->
        entities.map { it.toDomain() }
    }

    val allOrders: Flow<List<Order>> = orderDao.getAllOrders().map { entities ->
        entities.map { it.toDomain() }
    }

    val favoriteIds: Flow<Set<Long>> = favoriteDao.getAllFavoriteIds().map { list ->
        list.toSet()
    }

    suspend fun addToCart(product: Product, quantity: Int = 1) {
        val existing = cartDao.getItemByProductId(product.id)
        if (existing != null) {
            cartDao.updateQuantity(existing.id, existing.quantity + quantity)
        } else {
            val cartEntity = CartEntity(
                productId = product.id,
                productName = product.name,
                banglaName = product.banglaName,
                price = product.price,
                imageUrl = product.imageUrl,
                quantity = quantity,
                sellerName = product.sellerName
            )
            cartDao.insertOrUpdateItem(cartEntity)
        }
    }

    suspend fun updateCartQuantity(cartId: Long, quantity: Int) {
        if (quantity <= 0) {
            cartDao.deleteItem(cartId)
        } else {
            cartDao.updateQuantity(cartId, quantity)
        }
    }

    suspend fun removeFromCart(cartId: Long) {
        cartDao.deleteItem(cartId)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }

    suspend fun toggleFavorite(productId: Long) {
        val isFav = favoriteDao.isFavorite(productId)
        if (isFav) {
            favoriteDao.removeFavorite(productId)
        } else {
            favoriteDao.addFavorite(FavoriteEntity(productId = productId))
        }
    }

    suspend fun placeOrder(
        customerName: String,
        phone: String,
        address: String,
        paymentMethod: String,
        items: List<CartItem>,
        totalAmount: Double
    ): Long {
        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val orderNo = "GK-" + (100000 + (Math.random() * 900000).toInt())
        val summary = items.joinToString(", ") { "${it.productName} (x${it.quantity})" }
        val totalQty = items.sumOf { it.quantity }

        val orderEntity = OrderEntity(
            orderNumber = orderNo,
            date = dateFormat.format(Date()),
            totalAmount = totalAmount,
            status = OrderStatus.CONFIRMED.name,
            customerName = customerName,
            phone = phone,
            address = address,
            paymentMethod = paymentMethod,
            itemsSummary = summary,
            totalQuantity = totalQty
        )

        val id = orderDao.insertOrder(orderEntity)
        cartDao.clearCart()
        return id
    }

    suspend fun addProduct(product: Product): Long {
        return productDao.insertProduct(ProductEntity.fromDomain(product))
    }

    suspend fun deleteProduct(productId: Long) {
        productDao.deleteProductById(productId)
        cartDao.deleteByProductId(productId)
        favoriteDao.removeFavorite(productId)
    }

    suspend fun updateOrderStatus(orderId: Long, status: OrderStatus) {
        orderDao.updateOrderStatus(orderId, status.name)
    }

    // ------------------------------------------------------------------
    // সার্ভার (api.php) এর সাথে যোগাযোগ — সার্ভারই আসল তথ্যের উৎস
    // ------------------------------------------------------------------

    /** সার্ভার থেকে প্রোডাক্ট এনে লোকাল ক্যাশ নতুন করে বসায়। ব্যর্থ হলে ApiException ছুড়ে। */
    suspend fun syncProducts() {
        val remote = withContext(Dispatchers.IO) { ApiClient.fetchProducts() }
        database.withTransaction {
            productDao.deleteAll()
            productDao.insertProducts(remote.map { ProductEntity.fromDomain(it) })
            cartDao.deleteOrphans()
            cartDao.refreshPrices()
            favoriteDao.deleteOrphans()
        }
    }

    /** সার্ভারে অর্ডার দেয়; সফল হলে ফোনের অর্ডার তালিকায়ও সেভ করে ও কার্ট খালি করে। */
    suspend fun placeOrderRemote(
        customerName: String,
        phone: String,
        address: String,
        paymentMethod: String,
        promoCode: String,
        items: List<CartItem>
    ): Order {
        val remote = withContext(Dispatchers.IO) {
            ApiClient.createOrder(customerName, phone, address, paymentMethod, promoCode, items)
        }
        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val entity = OrderEntity(
            orderNumber = remote.orderNumber,
            date = dateFormat.format(Date()),
            totalAmount = remote.total,
            status = remote.status,
            customerName = customerName,
            phone = phone,
            address = address,
            paymentMethod = paymentMethod,
            itemsSummary = items.joinToString(", ") { "${it.productName} (x${it.quantity})" },
            totalQuantity = items.sumOf { it.quantity }
        )
        val id = orderDao.insertOrder(entity)
        cartDao.clearCart()
        return entity.copy(id = id).toDomain()
    }

    /** ফোনে সেভ থাকা অর্ডারগুলোর নতুন স্ট্যাটাস সার্ভার থেকে আনে। */
    suspend fun refreshOrderStatuses() {
        val local = orderDao.getAllOrdersList()
        if (local.isEmpty()) return
        val statuses = withContext(Dispatchers.IO) {
            ApiClient.trackOrders(local.map { it.orderNumber to it.phone })
        }
        for (order in local) {
            val newStatus = statuses[order.orderNumber]
            if (newStatus != null && newStatus != order.status) {
                orderDao.updateOrderStatus(order.id, newStatus)
            }
        }
    }

    suspend fun sellerLogin(email: String, password: String): SellerSession =
        withContext(Dispatchers.IO) { ApiClient.login(email, password) }

    suspend fun sellerOrders(token: String): List<Order> =
        withContext(Dispatchers.IO) { ApiClient.sellerOrders(token) }

    suspend fun sellerAddProduct(
        token: String,
        name: String,
        banglaName: String,
        category: String,
        price: Double,
        originalPrice: Double,
        imageUrl: String,
        description: String,
        stock: Int
    ) = withContext(Dispatchers.IO) {
        ApiClient.addProduct(token, name, banglaName, category, price, originalPrice, imageUrl, description, stock)
    }

    suspend fun sellerDeleteProduct(token: String, productId: Long) =
        withContext(Dispatchers.IO) { ApiClient.deleteProduct(token, productId) }
}
