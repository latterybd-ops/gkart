package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Palette
val BrandBluePrimary = Color(0xFF1E40AF)
val BrandBlueLight = Color(0xFF3B82F6)
val BrandBlueDark = Color(0xFF1E3A8A)

// Secondary Accent (Teal / Emerald)
val BrandTeal = Color(0xFF0D9488)
val BrandTealLight = Color(0xFF14B8A6)
val BrandEmerald = Color(0xFF10B981)

// Tertiary (Warm Amber / Coral)
val BrandAmber = Color(0xFFF59E0B)
val BrandCoral = Color(0xFFEF4444)

// Neutral & Background
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF131C31)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
